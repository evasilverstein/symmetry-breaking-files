# Training Data Overlap Analysis

## Overview

This document analyzes whether our logic puzzle evaluation prompts appear in the FineWeb-Edu training data. Understanding data overlap is critical for properly interpreting model performance on these tasks.

**Dataset**: FineWeb-Edu 10B (first 500M tokens used for training)
**Analysis Date**: 2026-01-04
**Method**: Exact token sequence matching using GPT-2 tokenizer

---

## Summary

| Task Category | Prompts in Training Data? | Full Sequence with Answer? | Interpretation |
|---------------|---------------------------|---------------------------|----------------|
| Pattern Numeric | Partial | Some yes | Mixed - may reflect memorization |
| Pattern Alpha | Partial | Some yes | Mixed - may reflect memorization |
| Fibonacci | Yes (pattern only) | **NO** | True reasoning test |
| Retrieval | **NO** | N/A | Novel - tests in-context learning |
| Inference | **NO** | N/A | Novel - tests reasoning |
| Copy | **NO** | N/A | Novel - tests in-context learning |

---

## Detailed Results

### Pattern Numeric Tasks

| Prompt | Found in Data? | With Answer? | Count |
|--------|----------------|--------------|-------|
| "1, 2, 3, 4," | Yes | "1, 2, 3, 4, 5" - 42x | 51 |
| "2, 4, 6, 8," | Yes | "2, 4, 6, 8, 10" - 1x | 3 |
| "1, 1, 2, 3, 5, 8," | Yes | "5, 8, 13" - **0x** | 5 |
| "10, 20, 30, 40," | Yes | Not checked | 1 |

**Key Finding**: The Fibonacci sequence continuation "5, 8, 13" does NOT appear in training data, making it a true test of pattern recognition/reasoning ability.

**Context Examples for "1, 2, 3, 4,"**:
- Citation lists: "[1, 2, 3, 4, 5, 6]"
- Numbered items: "example-1, 2, 3, 4, 5..."
- Biblical references: "verses: 4:1, 2, 3, 4, & twice..."

These are NOT sequence completion tasks - the pattern appears in document structure, not as "predict the next number" exercises.

### Pattern Alpha Tasks

| Prompt | Found in Data? | With Answer? | Count |
|--------|----------------|--------------|-------|
| "A, B, C, D," | Yes | "A, B, C, D, E" - 20x | 29 |
| "X, Y, Z, A," | **NO** | N/A | 0 |

**Key Finding**: "X, Y, Z, A," is completely novel - tests true alphabet wrap-around understanding.

### Retrieval Tasks (All Novel)

| Prompt | Found? |
|--------|--------|
| "The color is blue. The shape is round." | **NO** |
| "John is tall. Mary is short." | **NO** |
| "The capital of France is Paris." | **NO** |
| "Alice likes apples. Bob likes bananas." | **NO** |

**Key Finding**: ALL retrieval prompts are completely novel to the model. Performance on these tasks purely reflects learned in-context learning capabilities, not memorization.

### Inference Tasks (All Novel)

| Prompt | Found? |
|--------|--------|
| "If it rains, the ground gets wet." | **NO** |
| "All birds can fly. A sparrow is a bird." | **NO** |

**Key Finding**: ALL inference prompts are completely novel. Performance reflects reasoning ability.

### Copy Tasks (All Novel)

| Prompt | Found? |
|--------|--------|
| "Copy: abc -> abc" | **NO** |
| "Repeat: hello -> hello" | **NO** |

**Key Finding**: The copy/repeat format is completely novel.

---

## Implications for Result Interpretation

### Tasks Where Memorization May Play a Role
- **Simple counting** (1,2,3,4 → 5): Models may have memorized this pattern
- **Alphabet sequence** (A,B,C,D → E): Models may have memorized this pattern

### Tasks That Are True Tests of Capability
1. **Fibonacci continuation** (1,1,2,3,5,8 → 13): Pattern seen, but continuation NOT in data
2. **Wrap-around alphabet** (X,Y,Z,A → B): Completely novel
3. **All retrieval tasks**: Completely novel - tests in-context learning
4. **All inference tasks**: Completely novel - tests reasoning
5. **All copy tasks**: Completely novel - tests in-context learning

### Recommended Reporting Strategy

When reporting results, distinguish between:

1. **Potentially memorized tasks**: pattern_numeric (except Fibonacci), pattern_alpha (A,B,C,D)
2. **True capability tests**: Fibonacci, X,Y,Z,A, all retrieval, all inference, all copy

---

## Technical Details

### Search Methodology

```python
# Token sequence search using numpy sliding window
from numpy.lib.stride_tricks import sliding_window_view

def fast_search(data, pattern):
    windows = sliding_window_view(data, len(pattern))
    matches = np.all(windows == pattern, axis=1)
    return np.sum(matches)
```

### Data Format

- FineWeb-Edu stored as binary files with 256 int32 header + uint16 tokens
- GPT-2 tokenizer used (same as training)
- Searched first 5 shards (500M tokens) matching training data

### Tokenization Examples

| Text | Tokens |
|------|--------|
| "1, 2, 3, 4," | [16, 11, 362, 11, 513, 11, 604, 11] |
| "A, B, C, D," | [32, 11, 347, 11, 327, 11, 360, 11] |

---

## Conclusion

The majority of our logic puzzle tasks (retrieval, inference, copy, Fibonacci, wrap-around alphabet) are **completely novel** to the model and represent true tests of learned capabilities. Simple counting and basic alphabet sequences may partially reflect memorization, but even these appear in different contexts (citations, lists) rather than as pattern completion exercises.

This analysis supports the validity of using these tasks to compare optimizer performance on reasoning capabilities.
