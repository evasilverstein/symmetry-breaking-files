#!/usr/bin/env python3
"""
Logic Puzzle Evaluation WITH bQ/bV Biases Applied

This version applies the mean bQ (and optionally bV) biases at inference time,
matching what happens during training/validation. This helps understand whether
the biases themselves affect reasoning performance or if it's just training dynamics.

Key difference from eval_logic_puzzles.py:
- Loads bQ/bV mean values from checkpoint (or uses defaults)
- Applies mean biases during forward pass
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import argparse
import json
import math
from pathlib import Path
from dataclasses import dataclass
import numpy as np

import tiktoken


@dataclass
class GPTConfig:
    context_length: int = 512
    vocab_size: int = 50304
    n_layer: int = 12
    n_head: int = 12
    n_embd: int = 768


class CausalSelfAttentionWithBias(nn.Module):
    """Attention with bQ/bV biases applied at inference."""

    def __init__(self, config, mean_Q=None, mean_K=None, mean_V=None,
                 use_q_bias=True, use_k_bias=True, use_v_bias=False):
        super().__init__()
        self.n_head = config.n_head
        self.d = config.n_embd // config.n_head
        self.c_attn = nn.Linear(config.n_embd, 3 * config.n_embd)
        self.c_proj = nn.Linear(config.n_embd, config.n_embd)

        mask = torch.tril(torch.ones(config.context_length, config.context_length))
        self.register_buffer("causal_mask", mask.view(1, 1, config.context_length, config.context_length))

        # Store bias configuration
        self.use_q_bias = use_q_bias
        self.use_k_bias = use_k_bias
        self.use_v_bias = use_v_bias

        # Default bias means (from train_gpt_unified.py)
        if mean_Q is None:
            mean_Q = torch.full((self.d,), 0.5)  # Default Q mean is 0.5
        if mean_K is None:
            mean_K = torch.full((self.d,), 0.3)  # Default K mean is 0.3
        if mean_V is None:
            mean_V = torch.zeros(self.d)  # Default V mean is 0.0

        # Register biases as buffers (expand to all heads)
        self.register_buffer("bQ", mean_Q.view(1, 1, 1, self.d).expand(1, self.n_head, 1, self.d).clone())
        self.register_buffer("bK", mean_K.view(1, 1, 1, self.d).expand(1, self.n_head, 1, self.d).clone())
        self.register_buffer("bV", mean_V.view(1, 1, 1, self.d).expand(1, self.n_head, 1, self.d).clone())

    def forward(self, x):
        B, T, C = x.shape
        qkv = self.c_attn(x)
        q, k, v = qkv.split(C, dim=2)
        q = q.view(B, T, self.n_head, self.d).transpose(1, 2)  # (B, nh, T, d)
        k = k.view(B, T, self.n_head, self.d).transpose(1, 2)
        v = v.view(B, T, self.n_head, self.d).transpose(1, 2)

        # Apply bQ if enabled
        if self.use_q_bias:
            q = q + self.bQ

        # Apply bK if enabled
        if self.use_k_bias:
            k = k + self.bK

        # Apply bV if enabled
        if self.use_v_bias:
            v = v + self.bV

        # Attention
        scores = (q @ k.transpose(-2, -1)) / math.sqrt(self.d)
        scores = scores.masked_fill(self.causal_mask[:, :, :T, :T] == 0, float('-inf'))
        att = F.softmax(scores, dim=-1)
        y = att @ v
        y = y.transpose(1, 2).contiguous().view(B, T, C)
        return self.c_proj(y)


class MLP(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.c_fc = nn.Linear(config.n_embd, 4 * config.n_embd)
        self.c_proj = nn.Linear(4 * config.n_embd, config.n_embd)

    def forward(self, x):
        return self.c_proj(F.gelu(self.c_fc(x)))


class Block(nn.Module):
    def __init__(self, config, mean_Q=None, mean_K=None, mean_V=None,
                 use_q_bias=True, use_k_bias=True, use_v_bias=False):
        super().__init__()
        self.ln_1 = nn.LayerNorm(config.n_embd)
        self.attn = CausalSelfAttentionWithBias(
            config, mean_Q=mean_Q, mean_K=mean_K, mean_V=mean_V,
            use_q_bias=use_q_bias, use_k_bias=use_k_bias, use_v_bias=use_v_bias
        )
        self.ln_2 = nn.LayerNorm(config.n_embd)
        self.mlp = MLP(config)

    def forward(self, x):
        x = x + self.attn(self.ln_1(x))
        x = x + self.mlp(self.ln_2(x))
        return x


class GPT(nn.Module):
    def __init__(self, config, mean_Q=None, mean_K=None, mean_V=None,
                 use_q_bias=True, use_k_bias=True, use_v_bias=False):
        super().__init__()
        self.config = config
        self.transformer = nn.ModuleDict(dict(
            wte=nn.Embedding(config.vocab_size, config.n_embd),
            wpe=nn.Embedding(config.context_length, config.n_embd),
            h=nn.ModuleList([
                Block(config, mean_Q=mean_Q, mean_K=mean_K, mean_V=mean_V,
                      use_q_bias=use_q_bias, use_k_bias=use_k_bias, use_v_bias=use_v_bias)
                for _ in range(config.n_layer)
            ]),
            ln_f=nn.LayerNorm(config.n_embd),
        ))
        self.lm_head = nn.Linear(config.n_embd, config.vocab_size, bias=False)
        self.transformer.wte.weight = self.lm_head.weight

    def forward(self, idx):
        B, T = idx.size()
        pos = torch.arange(0, T, dtype=torch.long, device=idx.device)
        x = self.transformer.wte(idx) + self.transformer.wpe(pos)
        for block in self.transformer.h:
            x = block(x)
        x = self.transformer.ln_f(x)
        logits = self.lm_head(x)
        return logits


def extract_bias_means(state_dict):
    """Extract mean_Q, mean_K, mean_V from checkpoint if present."""
    mean_Q = None
    mean_K = None
    mean_V = None

    # Look for mean values in first layer
    for k, v in state_dict.items():
        if 'h.0.' in k and 'mean_Q' in k:
            mean_Q = v.clone()
        if 'h.0.' in k and 'mean_K' in k:
            mean_K = v.clone()
        if 'h.0.' in k and 'mean_V' in k:
            mean_V = v.clone()

    # Also check without layer prefix (for different save formats)
    for k, v in state_dict.items():
        if 'mean_Q' in k and mean_Q is None:
            mean_Q = v.clone()
            break
    for k, v in state_dict.items():
        if 'mean_K' in k and mean_K is None:
            mean_K = v.clone()
            break
    for k, v in state_dict.items():
        if 'mean_V' in k and mean_V is None:
            mean_V = v.clone()
            break

    return mean_Q, mean_K, mean_V


def load_model_with_biases(ckpt_path, device='cuda', use_q_bias=True, use_k_bias=True, use_v_bias=False,
                           override_mean_Q=None, override_mean_K=None, override_mean_V=None):
    """Load a checkpoint with bQ/bV biases applied at inference."""

    print(f"Loading checkpoint: {ckpt_path}")
    ckpt = torch.load(ckpt_path, map_location='cpu', weights_only=False)

    # Get config
    config_dict = ckpt.get('config', {})

    MODEL_PRESETS = {
        '124m': {'n_layer': 12, 'n_head': 12, 'n_embd': 768},
        '355m': {'n_layer': 24, 'n_head': 16, 'n_embd': 1024},
    }

    if isinstance(config_dict, dict) and 'model' in config_dict:
        preset = MODEL_PRESETS.get(config_dict['model'], MODEL_PRESETS['124m'])
        config = GPTConfig(
            context_length=config_dict.get('context_length', 512),
            vocab_size=config_dict.get('vocab_size', 50304),
            n_layer=preset['n_layer'],
            n_head=preset['n_head'],
            n_embd=preset['n_embd']
        )
    else:
        config = GPTConfig(
            context_length=getattr(config_dict, 'context_length', 512),
            vocab_size=getattr(config_dict, 'vocab_size', 50304),
            n_layer=getattr(config_dict, 'n_layer', 12),
            n_head=getattr(config_dict, 'n_head', 12),
            n_embd=getattr(config_dict, 'n_embd', 768)
        )

    # Load state dict
    if 'model' in ckpt:
        state_dict = ckpt['model']
    elif 'model_state_dict' in ckpt:
        state_dict = ckpt['model_state_dict']
    else:
        raise KeyError(f"No model weights found. Keys: {list(ckpt.keys())}")

    # Extract bias means from checkpoint
    mean_Q, mean_K, mean_V = extract_bias_means(state_dict)

    # Apply overrides
    if override_mean_Q is not None:
        mean_Q = override_mean_Q
    if override_mean_K is not None:
        mean_K = override_mean_K
    if override_mean_V is not None:
        mean_V = override_mean_V

    # Use defaults if not found
    d = config.n_embd // config.n_head
    if mean_Q is None:
        mean_Q = torch.full((d,), 0.5)
        print("  Using default mean_Q = 0.5")
    else:
        print(f"  Loaded mean_Q from checkpoint: mean={mean_Q.mean().item():.4f}")

    if mean_K is None:
        mean_K = torch.full((d,), 0.3)
        print("  Using default mean_K = 0.3")
    else:
        print(f"  Loaded mean_K from checkpoint: mean={mean_K.mean().item():.4f}")

    if mean_V is None:
        mean_V = torch.zeros(d)
        print("  Using default mean_V = 0.0")
    else:
        print(f"  Loaded mean_V from checkpoint: mean={mean_V.mean().item():.4f}")

    # Build model with biases
    print(f"  use_q_bias={use_q_bias}, use_k_bias={use_k_bias}, use_v_bias={use_v_bias}")
    model = GPT(config, mean_Q=mean_Q, mean_K=mean_K, mean_V=mean_V,
                use_q_bias=use_q_bias, use_k_bias=use_k_bias, use_v_bias=use_v_bias)

    # Clean up state dict keys, excluding bQ/bK/bV buffers (we use our own mean-based ones)
    cleaned = {}
    for k, v in state_dict.items():
        k_clean = k.replace('_orig_mod.', '')
        k_clean = k_clean.replace('.sa.', '.attn.')
        # Skip bQ/bK/bV buffers - we'll use the mean values instead
        if any(x in k_clean for x in ['.bQ', '.bK', '.bV', '.mean_Q', '.mean_K', '.mean_V', '.std_Q', '.std_K', '.std_V']):
            continue
        cleaned[k_clean] = v

    # Load with strict=False
    model.load_state_dict(cleaned, strict=False)
    model = model.to(device)
    model.eval()

    return model, config


# ============================================================================
# Evaluation Tasks (same as original)
# ============================================================================

def compute_perplexity(model, tokens, device):
    tokens = torch.tensor(tokens, dtype=torch.long, device=device).unsqueeze(0)
    with torch.no_grad():
        logits = model(tokens)
        logits = logits[:, :-1, :]
        targets = tokens[:, 1:]
        loss = F.cross_entropy(logits.reshape(-1, logits.size(-1)),
                               targets.reshape(-1), reduction='mean')
    return torch.exp(loss).item()


def get_next_token_probs(model, tokens, device, top_k=10):
    tokens = torch.tensor(tokens, dtype=torch.long, device=device).unsqueeze(0)
    with torch.no_grad():
        logits = model(tokens)
        probs = F.softmax(logits[0, -1, :], dim=-1)
        top_probs, top_indices = torch.topk(probs, top_k)
    return top_indices.cpu().tolist(), top_probs.cpu().tolist()


TASKS = {
    "pattern_numeric": [
        {"prompt": "1, 2, 3, 4,", "expected": " 5", "type": "completion"},
        {"prompt": "2, 4, 6, 8,", "expected": " 10", "type": "completion"},
        {"prompt": "1, 1, 2, 3, 5, 8,", "expected": " 13", "type": "completion"},
        {"prompt": "10, 20, 30, 40,", "expected": " 50", "type": "completion"},
    ],
    "pattern_alpha": [
        {"prompt": "A, B, C, D,", "expected": " E", "type": "completion"},
        {"prompt": "X, Y, Z, A,", "expected": " B", "type": "completion"},
    ],
    "retrieval_near": [
        {"prompt": "The color is blue. The shape is round. The color is", "expected": " blue", "type": "completion"},
        {"prompt": "John is tall. Mary is short. John is", "expected": " tall", "type": "completion"},
    ],
    "retrieval_far": [
        {"prompt": "The capital of France is Paris. The capital of Germany is Berlin. The capital of Spain is Madrid. The capital of Italy is Rome. The capital of France is", "expected": " Paris", "type": "completion"},
        {"prompt": "Alice likes apples. Bob likes bananas. Carol likes cherries. Dave likes dates. Alice likes", "expected": " apples", "type": "completion"},
    ],
    "simple_inference": [
        {"prompt": "If it rains, the ground gets wet. It is raining. The ground", "expected": " gets wet", "type": "completion"},
        {"prompt": "All birds can fly. A sparrow is a bird. A sparrow can", "expected": " fly", "type": "completion"},
    ],
    "negation": [
        {"prompt": "The sun is bright.", "compare": "The sun is not bright.", "type": "perplexity_compare"},
        {"prompt": "Water is wet.", "compare": "Water is not wet.", "type": "perplexity_compare"},
        {"prompt": "Fire is hot.", "compare": "Fire is not hot.", "type": "perplexity_compare"},
    ],
    "syntax": [
        {"prompt": "Hello, world!", "compare": "Hello world", "type": "perplexity_compare"},
        {"prompt": '"I am here," she said.', "compare": "I am here she said", "type": "perplexity_compare"},
    ],
    "copy": [
        {"prompt": "Copy: abc -> abc. Copy: xyz ->", "expected": " xyz", "type": "completion"},
        {"prompt": "Repeat: hello -> hello. Repeat: world ->", "expected": " world", "type": "completion"},
    ],
}


def run_completion_task(model, enc, task, device):
    prompt_tokens = enc.encode(task["prompt"])
    expected_tokens = enc.encode(task["expected"])
    top_indices, top_probs = get_next_token_probs(model, prompt_tokens, device, top_k=10)
    expected_first = expected_tokens[0] if expected_tokens else None

    return {
        "prompt": task["prompt"],
        "expected": task["expected"],
        "top_predictions": [enc.decode([idx]) for idx in top_indices[:5]],
        "top_probs": top_probs[:5],
        "expected_in_top1": expected_first == top_indices[0] if expected_first else False,
        "expected_in_top5": expected_first in top_indices[:5] if expected_first else False,
        "expected_rank": top_indices.index(expected_first) + 1 if expected_first in top_indices else -1,
    }


def run_perplexity_compare_task(model, enc, task, device):
    tokens1 = enc.encode(task["prompt"])
    tokens2 = enc.encode(task["compare"])
    ppl1 = compute_perplexity(model, tokens1, device)
    ppl2 = compute_perplexity(model, tokens2, device)

    return {
        "prompt1": task["prompt"],
        "prompt2": task["compare"],
        "ppl1": ppl1,
        "ppl2": ppl2,
        "ppl_ratio": ppl2 / ppl1 if ppl1 > 0 else float('inf'),
    }


def evaluate_model(model, enc, device):
    results = {}
    for task_category, tasks in TASKS.items():
        category_results = []
        for task in tasks:
            if task["type"] == "completion":
                result = run_completion_task(model, enc, task, device)
            elif task["type"] == "perplexity_compare":
                result = run_perplexity_compare_task(model, enc, task, device)
            else:
                continue
            category_results.append(result)
        results[task_category] = category_results
    return results


def summarize_results(results):
    summary = {}
    for category, tasks in results.items():
        if not tasks:
            continue
        if tasks[0].get("expected_in_top1") is not None:
            top1_acc = sum(1 for t in tasks if t["expected_in_top1"]) / len(tasks)
            top5_acc = sum(1 for t in tasks if t["expected_in_top5"]) / len(tasks)
            avg_rank = np.mean([t["expected_rank"] for t in tasks if t["expected_rank"] > 0]) if any(t["expected_rank"] > 0 for t in tasks) else -1
            summary[category] = {
                "top1_accuracy": top1_acc,
                "top5_accuracy": top5_acc,
                "avg_rank": avg_rank,
                "n_tasks": len(tasks),
            }
        else:
            avg_ratio = np.mean([t["ppl_ratio"] for t in tasks])
            summary[category] = {
                "avg_ppl_ratio": avg_ratio,
                "n_tasks": len(tasks),
            }
    return summary


def main():
    parser = argparse.ArgumentParser(description='Evaluate models on logic puzzles WITH bQ/bV biases')
    parser.add_argument('--checkpoint', type=str, required=True, help='Checkpoint to evaluate')
    parser.add_argument('--output', type=str, default='logic_eval_with_biases.json', help='Output file')
    parser.add_argument('--use_q_bias', action='store_true', default=True, help='Apply bQ bias (default True)')
    parser.add_argument('--no_q_bias', dest='use_q_bias', action='store_false', help='Disable bQ bias')
    parser.add_argument('--use_k_bias', action='store_true', default=True, help='Apply bK bias (default True)')
    parser.add_argument('--no_k_bias', dest='use_k_bias', action='store_false', help='Disable bK bias')
    parser.add_argument('--use_v_bias', action='store_true', default=False, help='Apply bV bias (default False)')
    parser.add_argument('--mean_Q', type=float, default=None, help='Override mean_Q value')
    parser.add_argument('--mean_K', type=float, default=None, help='Override mean_K value')
    parser.add_argument('--mean_V', type=float, default=None, help='Override mean_V value')
    args = parser.parse_args()

    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"Using device: {device}")

    enc = tiktoken.get_encoding("gpt2")

    # Prepare override values
    d = 64  # Default head dim for 124M
    override_mean_Q = torch.full((d,), args.mean_Q) if args.mean_Q is not None else None
    override_mean_K = torch.full((d,), args.mean_K) if args.mean_K is not None else None
    override_mean_V = torch.full((d,), args.mean_V) if args.mean_V is not None else None

    print(f"\n{'='*60}")
    print(f"Evaluating WITH biases: {args.checkpoint}")
    print(f"{'='*60}")

    model, config = load_model_with_biases(
        args.checkpoint, device,
        use_q_bias=args.use_q_bias,
        use_k_bias=args.use_k_bias,
        use_v_bias=args.use_v_bias,
        override_mean_Q=override_mean_Q,
        override_mean_K=override_mean_K,
        override_mean_V=override_mean_V
    )

    results = evaluate_model(model, enc, device)
    summary = summarize_results(results)

    output_data = {
        "custom": {
            "checkpoint": args.checkpoint,
            "bias_config": {
                "use_q_bias": args.use_q_bias,
                "use_k_bias": args.use_k_bias,
                "use_v_bias": args.use_v_bias,
                "mean_Q_override": args.mean_Q,
                "mean_K_override": args.mean_K,
                "mean_V_override": args.mean_V,
            },
            "summary": summary,
            "detailed": results,
        }
    }

    print(f"\nSummary:")
    for category, stats in summary.items():
        print(f"  {category}:")
        for k, v in stats.items():
            if isinstance(v, float):
                print(f"    {k}: {v:.3f}")
            else:
                print(f"    {k}: {v}")

    output_path = Path(args.output)
    with open(output_path, 'w') as f:
        json.dump(output_data, f, indent=2, default=str)
    print(f"\nResults saved to: {output_path}")


if __name__ == "__main__":
    main()
