#!/usr/bin/env python3
"""
Comprehensive Smoothed Validation Analysis

This script:
1. Loads all WandB exported data from CSV files
2. Adds local results (from results.json files) not in WandB
3. Computes smoothed metrics for comparison
4. Generates comparison tables and statistical tests
"""

import pandas as pd
import numpy as np
from pathlib import Path
from scipy import stats
import json


def load_all_csv_results(results_dir):
    """Load all CSV files from the results directory."""
    results_dir = Path(results_dir)
    all_data = []

    for csv_file in results_dir.glob("*.csv"):
        if "latest" in csv_file.name:  # Only use latest files
            df = pd.read_csv(csv_file)
            df['source_file'] = csv_file.name
            all_data.append(df)

    if all_data:
        combined = pd.concat(all_data, ignore_index=True)
        # Remove duplicates based on run name
        combined = combined.drop_duplicates(subset=['name'], keep='first')
        return combined
    return pd.DataFrame()


def load_local_results(results_base_dir):
    """Load local results.json files that may not be in WandB."""
    results_base = Path(results_base_dir)
    local_results = []

    # Check key directories for results.json files
    key_dirs = [
        "124m_extended/sgdm_best_symmetric",
        "124m_extended/sgdm_best_disordered",
        "124m_extended/ecd_symmetric",
        "124m_extended/ecd_bQ_only",
        "124m_extended/adamw_symmetric_retrain",
        "124m_extended/soap_symmetric_retrain",
    ]

    for dir_path in key_dirs:
        full_path = results_base / dir_path
        if full_path.exists():
            for json_file in full_path.glob("results_*.json"):
                try:
                    with open(json_file) as f:
                        data = json.load(f)

                    # Extract optimizer from directory name
                    optimizer = "unknown"
                    if "sgdm" in dir_path.lower():
                        optimizer = "sgdm"
                    elif "ecd" in dir_path.lower():
                        optimizer = "ecd"
                    elif "adamw" in dir_path.lower():
                        optimizer = "adamw"
                    elif "soap" in dir_path.lower():
                        optimizer = "soap"

                    # Determine config type
                    config = "unknown"
                    if "symmetric" in dir_path:
                        config = "symmetric"
                    elif "disordered" in dir_path or "bQ_only" in dir_path:
                        config = "bQ_only"
                    elif "bV" in dir_path:
                        config = "bQ+bV"

                    local_results.append({
                        'name': data.get('run_name', json_file.stem),
                        'raw_min': data.get('best_val_loss'),
                        'raw_final': data.get('final_val_loss'),
                        'smoothed_min': data.get('best_val_loss'),  # No smoothing available
                        'smoothed_final': data.get('final_val_loss'),
                        'optimizer': optimizer,
                        'config': config,
                        'source': 'local',
                        'state': 'finished'
                    })
                except Exception as e:
                    print(f"Warning: Could not load {json_file}: {e}")

    return pd.DataFrame(local_results)


def categorize_runs(df):
    """Add categories to runs based on their names."""
    def get_config(name):
        name_lower = name.lower()
        if 'rope' in name_lower:
            return 'bQ+bV+RoPE'
        elif 'bv' in name_lower or 'stdv' in name_lower:
            return 'bQ+bV'
        elif 'disordered' in name_lower or 'bq' in name_lower:
            return 'bQ_only'
        elif 'symmetric' in name_lower:
            return 'symmetric'
        else:
            return 'unknown'

    def get_optimizer(row):
        name_lower = row['name'].lower()
        if pd.notna(row.get('optimizer')) and row['optimizer']:
            return str(row['optimizer']).lower()
        if 'adam' in name_lower and 'soap' not in name_lower:
            return 'adamw'
        elif 'soap' in name_lower:
            return 'soap'
        elif 'sgdm' in name_lower:
            return 'sgdm'
        elif 'ecd' in name_lower:
            return 'ecd'
        else:
            return 'unknown'

    df = df.copy()
    df['config'] = df['name'].apply(get_config)
    df['optimizer_cat'] = df.apply(get_optimizer, axis=1)

    return df


def compute_statistical_tests(df):
    """Compute statistical significance tests between groups."""
    results = []

    # Get unique optimizers and configs
    optimizers = df['optimizer_cat'].unique()
    configs = df['config'].unique()

    # Test: bQ_only vs bQ+bV for each optimizer
    for opt in optimizers:
        opt_data = df[df['optimizer_cat'] == opt]

        bq_only = opt_data[opt_data['config'] == 'bQ_only']['raw_min'].dropna()
        bq_bv = opt_data[opt_data['config'] == 'bQ+bV']['raw_min'].dropna()

        if len(bq_only) >= 2 and len(bq_bv) >= 2:
            t_stat, p_value = stats.ttest_ind(bq_only, bq_bv)
            results.append({
                'test': f'{opt}: bQ_only vs bQ+bV',
                'group1_mean': bq_only.mean(),
                'group1_std': bq_only.std(),
                'group1_n': len(bq_only),
                'group2_mean': bq_bv.mean(),
                'group2_std': bq_bv.std(),
                'group2_n': len(bq_bv),
                't_statistic': t_stat,
                'p_value': p_value,
                'significant': p_value < 0.05
            })

    # Test: ECD vs SGDM for bQ+bV
    for config in ['bQ+bV', 'symmetric', 'bQ_only']:
        config_data = df[df['config'] == config]

        ecd = config_data[config_data['optimizer_cat'] == 'ecd']['raw_min'].dropna()
        sgdm = config_data[config_data['optimizer_cat'] == 'sgdm']['raw_min'].dropna()

        if len(ecd) >= 2 and len(sgdm) >= 2:
            t_stat, p_value = stats.ttest_ind(ecd, sgdm)
            results.append({
                'test': f'{config}: ECD vs SGDM',
                'group1_mean': ecd.mean(),
                'group1_std': ecd.std(),
                'group1_n': len(ecd),
                'group2_mean': sgdm.mean(),
                'group2_std': sgdm.std(),
                'group2_n': len(sgdm),
                't_statistic': t_stat,
                'p_value': p_value,
                'significant': p_value < 0.05
            })

    return pd.DataFrame(results)


def generate_summary_tables(df):
    """Generate summary tables by optimizer and config."""
    summary = df.groupby(['optimizer_cat', 'config']).agg({
        'raw_min': ['mean', 'std', 'min', 'max', 'count'],
        'smoothed_final': ['mean', 'std']
    }).round(4)

    return summary


def main():
    script_dir = Path(__file__).parent
    results_dir = script_dir.parent / "results"
    local_results_base = script_dir.parent.parent / "results"

    print("=" * 80)
    print("COMPREHENSIVE SMOOTHED VALIDATION ANALYSIS")
    print("=" * 80)

    # Load WandB data
    print("\n1. Loading WandB CSV data...")
    wandb_data = load_all_csv_results(results_dir)
    print(f"   Loaded {len(wandb_data)} runs from WandB")

    # Load local results
    print("\n2. Loading local results.json files...")
    local_data = load_local_results(local_results_base)
    print(f"   Loaded {len(local_data)} runs from local files")

    # Combine data
    if len(local_data) > 0:
        # Add local data that's not already in WandB data
        local_names = set(local_data['name'])
        wandb_names = set(wandb_data['name']) if len(wandb_data) > 0 else set()
        new_local = local_data[~local_data['name'].isin(wandb_names)]
        print(f"   Adding {len(new_local)} new runs from local data")

        combined = pd.concat([wandb_data, new_local], ignore_index=True)
    else:
        combined = wandb_data

    # Categorize runs
    print("\n3. Categorizing runs...")
    combined = categorize_runs(combined)

    # Summary by optimizer and config
    print("\n" + "=" * 80)
    print("SUMMARY BY OPTIMIZER AND CONFIG")
    print("=" * 80)

    summary = generate_summary_tables(combined)
    print(summary.to_string())

    # Best runs per category
    print("\n" + "=" * 80)
    print("BEST RUNS (by raw_min validation loss)")
    print("=" * 80)

    for opt in sorted(combined['optimizer_cat'].unique()):
        print(f"\n--- {opt.upper()} ---")
        opt_data = combined[combined['optimizer_cat'] == opt]

        for config in sorted(opt_data['config'].unique()):
            config_data = opt_data[opt_data['config'] == config]
            if len(config_data) > 0:
                best = config_data.loc[config_data['raw_min'].idxmin()]
                print(f"  {config}: {best['raw_min']:.4f} ({best['name']})")

    # Statistical tests
    print("\n" + "=" * 80)
    print("STATISTICAL SIGNIFICANCE TESTS")
    print("=" * 80)

    stats_results = compute_statistical_tests(combined)
    if len(stats_results) > 0:
        for _, row in stats_results.iterrows():
            sig = "***" if row['significant'] else ""
            print(f"\n{row['test']} {sig}")
            print(f"  Group 1: {row['group1_mean']:.4f} ± {row['group1_std']:.4f} (n={row['group1_n']})")
            print(f"  Group 2: {row['group2_mean']:.4f} ± {row['group2_std']:.4f} (n={row['group2_n']})")
            print(f"  t={row['t_statistic']:.3f}, p={row['p_value']:.4f}")
    else:
        print("  Not enough data for statistical tests (need at least 2 samples per group)")

    # Key comparisons table
    print("\n" + "=" * 80)
    print("KEY COMPARISONS: BEST VALIDATION LOSS")
    print("=" * 80)

    comparison_data = []
    for opt in ['ecd', 'sgdm', 'adamw', 'soap']:
        opt_data = combined[combined['optimizer_cat'] == opt]
        row = {'optimizer': opt.upper()}
        for config in ['symmetric', 'bQ_only', 'bQ+bV']:
            config_data = opt_data[opt_data['config'] == config]
            if len(config_data) > 0:
                row[config] = f"{config_data['raw_min'].min():.4f}"
            else:
                row[config] = "N/A"
        comparison_data.append(row)

    comparison_df = pd.DataFrame(comparison_data)
    comparison_df = comparison_df.set_index('optimizer')
    print(comparison_df.to_string())

    # Save comprehensive results
    output_file = results_dir / "comprehensive_analysis.csv"
    combined.to_csv(output_file, index=False)
    print(f"\nResults saved to: {output_file}")

    # Save statistics
    stats_file = results_dir / "statistical_tests.csv"
    stats_results.to_csv(stats_file, index=False)
    print(f"Statistics saved to: {stats_file}")


if __name__ == "__main__":
    main()
