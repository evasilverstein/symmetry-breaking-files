#!/usr/bin/env python3
"""
Fetch WandB run histories and compute smoothed validation loss metrics.

Usage (for our ECD vs SOAP project):
    # Analyze all finished runs in ecd-full-symbreak project:
    python wandb_smoothed_analysis.py

    # Analyze specific runs:
    python wandb_smoothed_analysis.py --runs soap-bV-flash-seed42 ecd-bV-flash-seed42

    # Analyze runs from a different project:
    python wandb_smoothed_analysis.py --project ecd-scale

    # Save results to CSV:
    python wandb_smoothed_analysis.py --output smoothed_results.csv

Notes:
    - This script uses CPU only (safe to run alongside GPU training)
    - Reports both raw_min (our primary metric) and smoothed metrics
    - Smoothed metrics use exponential weighted moving average (EWM)
"""

import argparse
import os
import pandas as pd
import numpy as np

try:
    import wandb
except ImportError:
    print("wandb not installed. Run: pip install wandb")
    exit(1)


def get_smoothed_metrics(run, metric_key="val/loss", alpha=0.1, samples=5000):
    """
    Fetch run history and compute smoothed metrics.
    
    Args:
        run: wandb Run object
        metric_key: the metric to analyze (e.g., "val/loss")
        alpha: EWM smoothing factor (lower = smoother, typical range 0.05-0.2)
        samples: number of data points to fetch
    
    Returns:
        dict with raw and smoothed metrics
    """
    try:
        # Fetch history
        history = run.history(keys=[metric_key], samples=samples, pandas=True)
        
        if history.empty or metric_key not in history.columns:
            return None
        
        # Drop NaN values
        values = history[metric_key].dropna()
        
        if len(values) == 0:
            return None
        
        # Compute smoothed series
        smoothed = values.ewm(alpha=alpha).mean()
        
        return {
            "raw_min": values.min(),
            "raw_final": values.iloc[-1],
            "smoothed_min": smoothed.min(),
            "smoothed_final": smoothed.iloc[-1],
            "n_points": len(values),
        }
    except Exception as e:
        print(f"  Warning: Could not fetch history for {run.name}: {e}")
        return None


def analyze_project_runs(entity, project, run_filter=None, metric_key="val/loss", 
                         alpha=0.1, samples=5000, state_filter="finished"):
    """
    Analyze all runs in a project.
    
    Args:
        entity: wandb entity (username or team)
        project: wandb project name
        run_filter: optional dict of filters (e.g., {"tags": "124m"})
        metric_key: metric to analyze
        alpha: smoothing factor
        samples: number of points to fetch per run
        state_filter: only include runs with this state (e.g., "finished")
    
    Returns:
        DataFrame with results
    """
    api = wandb.Api()
    
    # Build filter
    filters = {}
    if state_filter:
        filters["state"] = state_filter
    if run_filter:
        filters.update(run_filter)
    
    # Fetch runs
    path = f"{entity}/{project}"
    print(f"Fetching runs from {path}...")
    
    runs = api.runs(path, filters=filters if filters else None)
    
    results = []
    for run in runs:
        print(f"  Processing: {run.name} ({run.state})")
        
        metrics = get_smoothed_metrics(run, metric_key, alpha, samples)
        
        if metrics is None:
            continue
        
        # Extract key config values
        config = run.config
        
        result = {
            "name": run.name,
            "id": run.id,
            "state": run.state,
            "raw_min": metrics["raw_min"],
            "raw_final": metrics["raw_final"],
            "smoothed_min": metrics["smoothed_min"],
            "smoothed_final": metrics["smoothed_final"],
            "n_points": metrics["n_points"],
            # Add useful config fields if present
            "optimizer": config.get("opt_kind", config.get("optimizer", "")),
            "lr": config.get("ecd.lr", config.get("optimizer.defaults.lr", "")),
            "std_V": config.get("symmetry_breaking.std_V", ""),
            "tags": ", ".join(run.tags) if run.tags else "",
        }
        results.append(result)
    
    return pd.DataFrame(results)


def analyze_specific_runs(entity, project, run_names_or_ids, metric_key="val/loss",
                          alpha=0.1, samples=5000):
    """
    Analyze specific runs by name or ID.

    Args:
        entity: wandb entity
        project: wandb project name
        run_names_or_ids: list of run names or IDs to analyze
        metric_key: metric to analyze
        alpha: smoothing factor
        samples: number of points to fetch

    Returns:
        DataFrame with results
    """
    api = wandb.Api()

    results = []
    for run_identifier in run_names_or_ids:
        print(f"  Processing: {run_identifier}")

        run = None
        # First try as run ID (8 char alphanumeric)
        if len(run_identifier) == 8 and run_identifier.isalnum():
            try:
                run = api.run(f"{entity}/{project}/{run_identifier}")
            except:
                pass

        # If not found, search by display_name
        if run is None:
            try:
                runs = api.runs(f"{entity}/{project}", filters={"display_name": run_identifier})
                runs_list = list(runs)
                # Filter for finished runs if multiple matches
                finished = [r for r in runs_list if r.state == "finished"]
                if finished:
                    run = finished[0]
                elif runs_list:
                    run = runs_list[0]
            except Exception as e:
                print(f"    Warning: Error searching for '{run_identifier}': {e}")
                continue

        if run is None:
            print(f"    Warning: Run '{run_identifier}' not found")
            continue

        metrics = get_smoothed_metrics(run, metric_key, alpha, samples)

        if metrics is None:
            continue

        config = run.config

        result = {
            "name": run.name,
            "id": run.id,
            "state": run.state,
            "raw_min": metrics["raw_min"],
            "raw_final": metrics["raw_final"],
            "smoothed_min": metrics["smoothed_min"],
            "smoothed_final": metrics["smoothed_final"],
            "n_points": metrics["n_points"],
            "optimizer": config.get("opt_kind", config.get("optimizer", "")),
            "lr": config.get("ecd.lr", config.get("optimizer.defaults.lr", "")),
            "std_V": config.get("symmetry_breaking.std_V", ""),
        }
        results.append(result)

    return pd.DataFrame(results)


def format_results_table(df, sort_by="smoothed_final"):
    """Format results as a nice table."""
    if df.empty:
        return "No results found."
    
    # Sort
    df_sorted = df.sort_values(sort_by)
    
    # Format for display
    display_cols = ["name", "raw_min", "smoothed_final", "raw_final", "optimizer", "std_V"]
    display_cols = [c for c in display_cols if c in df_sorted.columns]
    
    # Round numeric columns
    for col in ["raw_min", "raw_final", "smoothed_min", "smoothed_final"]:
        if col in df_sorted.columns:
            df_sorted[col] = df_sorted[col].round(4)
    
    return df_sorted[display_cols].to_string(index=False)


def main():
    parser = argparse.ArgumentParser(description="Fetch and analyze WandB run metrics with smoothing")
    parser.add_argument("--api_key", type=str, default=None,
                        help="WandB API key (or set WANDB_API_KEY env var)")
    parser.add_argument("--entity", type=str, default="ecdsep-arxiv",
                        help="WandB entity (default: ecdsep-arxiv)")
    parser.add_argument("--project", type=str, default="ecd-full-symbreak",
                        help="WandB project name (default: ecd-full-symbreak)")
    parser.add_argument("--runs", type=str, nargs="*", default=None,
                        help="Specific run names/IDs to analyze (if not provided, analyzes all finished runs)")
    parser.add_argument("--metric", type=str, default="val/loss",
                        help="Metric key to analyze (default: val/loss)")
    parser.add_argument("--alpha", type=float, default=0.1,
                        help="EWM smoothing alpha (lower = smoother, default: 0.1)")
    parser.add_argument("--samples", type=int, default=5000,
                        help="Number of data points to fetch per run (default: 5000)")
    parser.add_argument("--output", type=str, default=None,
                        help="Output CSV file path (optional)")
    parser.add_argument("--tags", type=str, nargs="*", default=None,
                        help="Filter runs by tags")
    parser.add_argument("--include-running", action="store_true",
                        help="Include running experiments (default: only finished)")
    parser.add_argument("--sort-by", type=str, default="raw_min",
                        choices=["raw_min", "smoothed_min", "smoothed_final", "raw_final"],
                        help="Sort results by this column (default: raw_min, our primary metric)")

    args = parser.parse_args()
    
    # Set API key if provided explicitly
    if args.api_key:
        os.environ["WANDB_API_KEY"] = args.api_key
    # Otherwise wandb.Api() will use ~/.netrc or existing login
    
    # Determine state filter
    state_filter = None if args.include_running else "finished"

    # Analyze runs
    if args.runs:
        # Analyze specific runs
        df = analyze_specific_runs(
            args.entity, args.project, args.runs,
            metric_key=args.metric, alpha=args.alpha, samples=args.samples
        )
    else:
        # Analyze all runs in project
        run_filter = {}
        if args.tags:
            run_filter["tags"] = {"$in": args.tags}

        df = analyze_project_runs(
            args.entity, args.project, run_filter=run_filter if run_filter else None,
            metric_key=args.metric, alpha=args.alpha, samples=args.samples,
            state_filter=state_filter
        )

    # Display results
    print("\n" + "="*80)
    print(f"RESULTS (sorted by {args.sort_by})")
    print("Primary metric: raw_min (best validation loss)")
    print("="*80)
    print(format_results_table(df, sort_by=args.sort_by))
    
    # Also show comparison
    if not df.empty:
        print("\n" + "="*80)
        print("COMPARISON: raw_min vs smoothed_final")
        print("="*80)
        df_compare = df[["name", "raw_min", "smoothed_final"]].copy()
        df_compare["delta"] = df_compare["smoothed_final"] - df_compare["raw_min"]
        df_compare = df_compare.sort_values("smoothed_final")
        for col in ["raw_min", "smoothed_final", "delta"]:
            df_compare[col] = df_compare[col].round(4)
        print(df_compare.to_string(index=False))
    
    # Save to CSV if requested
    if args.output:
        df.to_csv(args.output, index=False)
        print(f"\nResults saved to {args.output}")


# Example usage for interactive/notebook environments
def quick_analysis(api_key, entity, project, alpha=0.1):
    """
    Quick analysis function for notebooks/interactive use.
    
    Example:
        import wandb_smoothed_metrics as wsm
        df = wsm.quick_analysis("your_api_key", "your_entity", "your_project")
    """
    os.environ["WANDB_API_KEY"] = api_key
    
    df = analyze_project_runs(entity, project, alpha=alpha)
    
    print(format_results_table(df))
    return df


if __name__ == "__main__":
    main()