#!/usr/bin/env python3
"""
Analyze WandB export files to find best runs for each optimizer/config combination.

This script processes the wandb_export CSV files and produces a comprehensive
summary table showing the best validation loss for each optimizer in each
symmetry-breaking configuration.
"""

import pandas as pd
import numpy as np
from pathlib import Path
import re


def load_wandb_exports(export_dir):
    """Load all wandb_export CSV files."""
    export_dir = Path(export_dir)
    all_data = []

    for csv_file in export_dir.glob("wandb_export_*.csv"):
        try:
            df = pd.read_csv(csv_file)
            df['source_file'] = csv_file.name
            all_data.append(df)
            print(f"Loaded {len(df)} rows from {csv_file.name}")
        except Exception as e:
            print(f"Warning: Could not load {csv_file}: {e}")

    if all_data:
        combined = pd.concat(all_data, ignore_index=True)
        # Normalize column names
        combined.columns = [c.strip() for c in combined.columns]
        return combined
    return pd.DataFrame()


def get_val_loss(row):
    """Extract validation loss from row, handling different column names."""
    for col in ['val/loss (Min)', 'val/loss', 'best_val_loss']:
        if col in row.index and pd.notna(row[col]):
            try:
                return float(row[col])
            except:
                pass
    return np.nan


def get_optimizer(row):
    """Determine optimizer from row data."""
    # Check explicit optimizer columns
    for col in ['opt_kind', 'optimizer', 'optimizer.kind']:
        if col in row.index and pd.notna(row[col]) and row[col]:
            opt = str(row[col]).lower()
            if 'ecd' in opt:
                return 'ECD'
            elif 'soap' in opt and 'adam' not in opt:
                return 'SOAP'
            elif 'adam' in opt and 'soap' not in opt:
                return 'AdamW'
            elif 'sgdm' in opt or 'sgd' in opt:
                return 'SGDM'

    # Check name
    name = str(row.get('Name', '')).lower()
    if 'ecd' in name and 'adam' not in name:
        return 'ECD'
    elif 'soap' in name and 'adam' not in name and 'hybrid' not in name:
        return 'SOAP'
    elif 'adam' in name and 'soap' not in name:
        return 'AdamW'
    elif 'sgdm' in name:
        return 'SGDM'

    # Check tags
    tags = str(row.get('Tags', '')).lower()
    if 'ecd' in tags and 'adam' not in tags:
        return 'ECD'
    elif 'soap' in tags:
        return 'SOAP'
    elif 'adam' in tags:
        return 'AdamW'
    elif 'sgdm' in tags:
        return 'SGDM'

    return 'Unknown'


def get_config(row):
    """Determine symmetry-breaking configuration from row data."""
    name = str(row.get('Name', '')).lower()
    tags = str(row.get('Tags', '')).lower()

    # Check for RoPE
    if 'rope' in name or 'rope' in tags:
        return 'bQ+bV+RoPE'

    # Check for bV (indicates bQ+bV since bQ is always on with bV)
    bv_col = row.get('symmetry_breaking.bV')
    std_v = row.get('symmetry_breaking.std_V')

    if 'bv' in name or 'stdv' in name or (pd.notna(bv_col) and bv_col == True):
        return 'bQ+bV'

    if pd.notna(std_v) and float(std_v) > 0:
        return 'bQ+bV'

    # Check for symmetric
    if 'symmetric' in name or 'symmetric' in tags:
        return 'symmetric'

    # Check for disordered/bQ-only
    if 'disordered' in name or 'bq' in name or 'disorder' in tags:
        return 'bQ_only'

    # Check use_disordered_attention column
    use_dis = row.get('use_disordered_attention')
    if pd.notna(use_dis):
        if use_dis == True or str(use_dis).lower() == 'true':
            # Has disordered attention but no bV - check if bV
            if pd.isna(std_v) or float(std_v) == 0:
                return 'bQ_only'
            else:
                return 'bQ+bV'
        else:
            return 'symmetric'

    # Check symmetry_breaking.bQ
    bq_col = row.get('symmetry_breaking.bQ')
    if pd.notna(bq_col) and bq_col == True:
        return 'bQ_only'

    return 'unknown'


def main():
    script_dir = Path(__file__).parent
    export_dir = script_dir.parent  # smoothed_validation folder

    print("=" * 80)
    print("WANDB EXPORT ANALYSIS")
    print("=" * 80)

    # Load all exports
    print("\n1. Loading WandB export files...")
    df = load_wandb_exports(export_dir)

    if len(df) == 0:
        print("No data found!")
        return

    print(f"\n   Total rows loaded: {len(df)}")

    # Extract key fields
    print("\n2. Processing runs...")
    df['val_loss_min'] = df.apply(get_val_loss, axis=1)
    df['optimizer_cat'] = df.apply(get_optimizer, axis=1)
    df['config'] = df.apply(get_config, axis=1)

    # Filter to finished runs with valid loss
    finished = df[
        (df['State'] == 'finished') &
        (df['val_loss_min'].notna()) &
        (df['val_loss_min'] > 0)
    ].copy()

    print(f"   Finished runs with valid loss: {len(finished)}")

    # Remove duplicates (keep best)
    finished = finished.sort_values('val_loss_min')
    finished = finished.drop_duplicates(subset=['Name'], keep='first')

    print(f"   Unique runs: {len(finished)}")

    # Summary by optimizer and config
    print("\n" + "=" * 80)
    print("RUNS BY OPTIMIZER AND CONFIG")
    print("=" * 80)

    for opt in ['ECD', 'SGDM', 'AdamW', 'SOAP']:
        opt_data = finished[finished['optimizer_cat'] == opt]
        print(f"\n--- {opt} ({len(opt_data)} runs) ---")

        for config in ['symmetric', 'bQ_only', 'bQ+bV', 'bQ+bV+RoPE', 'unknown']:
            config_data = opt_data[opt_data['config'] == config]
            if len(config_data) > 0:
                best = config_data.loc[config_data['val_loss_min'].idxmin()]
                print(f"  {config:15s}: {best['val_loss_min']:.4f} ({best['Name']}) [n={len(config_data)}]")

    # Create best runs table
    print("\n" + "=" * 80)
    print("BEST VALIDATION LOSS BY OPTIMIZER AND CONFIG")
    print("=" * 80)

    results = []
    for opt in ['ECD', 'SGDM', 'AdamW', 'SOAP']:
        opt_data = finished[finished['optimizer_cat'] == opt]
        row = {'Optimizer': opt}

        for config in ['symmetric', 'bQ_only', 'bQ+bV']:
            config_data = opt_data[opt_data['config'] == config]
            if len(config_data) > 0:
                best = config_data.loc[config_data['val_loss_min'].idxmin()]
                row[config] = best['val_loss_min']
                row[f'{config}_name'] = best['Name']
            else:
                row[config] = np.nan
                row[f'{config}_name'] = 'N/A'

        results.append(row)

    results_df = pd.DataFrame(results)
    print("\nValidation Loss (lower is better):")
    print(results_df[['Optimizer', 'symmetric', 'bQ_only', 'bQ+bV']].to_string(index=False))

    print("\nBest Run Names:")
    for _, row in results_df.iterrows():
        print(f"\n{row['Optimizer']}:")
        for config in ['symmetric', 'bQ_only', 'bQ+bV']:
            if pd.notna(row[config]):
                print(f"  {config}: {row[f'{config}_name']} ({row[config]:.4f})")

    # Save results
    output_file = script_dir.parent / "results" / "best_runs_by_config.csv"
    results_df.to_csv(output_file, index=False)
    print(f"\nResults saved to: {output_file}")

    # Export detailed data
    detail_file = script_dir.parent / "results" / "all_runs_categorized.csv"
    finished[['Name', 'val_loss_min', 'optimizer_cat', 'config', 'State', 'Tags']].to_csv(
        detail_file, index=False
    )
    print(f"Detailed data saved to: {detail_file}")

    # Check for missing configurations
    print("\n" + "=" * 80)
    print("MISSING CONFIGURATIONS")
    print("=" * 80)

    for opt in ['ECD', 'SGDM', 'AdamW', 'SOAP']:
        opt_data = finished[finished['optimizer_cat'] == opt]
        missing = []
        for config in ['symmetric', 'bQ_only', 'bQ+bV']:
            config_data = opt_data[opt_data['config'] == config]
            if len(config_data) == 0:
                missing.append(config)
        if missing:
            print(f"  {opt}: MISSING {', '.join(missing)}")
        else:
            print(f"  {opt}: All configs present ✓")


if __name__ == "__main__":
    main()
