# Smoothed Validation Loss Analysis

This folder contains comprehensive analysis of validation loss curves from all ECD vs SOAP optimizer comparison experiments.

## Folder Structure

```
smoothed_validation/
├── README.md                    # This file
├── wandb_export_*.csv           # WandB export data (uploaded)
├── scripts/                     # Analysis scripts
│   ├── wandb_smoothed_analysis.py       # Fetch and analyze WandB data via API
│   ├── comprehensive_analysis.py        # Full analysis with statistics
│   └── analyze_wandb_exports.py         # Analyze uploaded WandB CSV exports
├── results/                     # CSV outputs
│   ├── best_runs_500M_tokens.csv        # Best run for each optimizer/config (500M tokens)
│   ├── all_runs_categorized.csv         # All runs with categories
│   ├── comprehensive_analysis.csv       # Combined API data
│   └── statistical_tests.csv            # Statistical test results
└── plots/                       # Generated plots (if any)
```

## Key Metrics

| Metric | Description |
|--------|-------------|
| `val/loss (Min)` | **Primary metric**: Minimum validation loss during training |
| `val/best_loss` | Equivalent metric in some exports |

**Important**: All comparisons below are filtered to runs with **~500M tokens** (400M-600M range) for fair comparison across optimizers and configurations.

## Summary Results (500M tokens, 66 runs)

### Best Validation Loss by Optimizer and Configuration

| Optimizer | Symmetric | bQ-only | bQ+bV | bQ+bV+RoPE | Best Config |
|-----------|-----------|---------|-------|------------|-------------|
| **ECD** | 3.933 | 3.847 | **3.347** | 3.358 | bQ+bV |
| **SGDM** | 3.842 | 3.800 | **3.666** | -- | bQ+bV |
| **AdamW** | 3.572 | 3.574 | **3.531** | -- | bQ+bV |
| **SOAP** | 3.416 | 4.163 | 3.374 | **3.331** | bQ+bV+RoPE |

### Overall Best Runs (500M tokens)

| Rank | Val Loss | Optimizer | Config | Run Name |
|------|----------|-----------|--------|----------|
| 1 | **3.331** | SOAP | bQ+bV+RoPE | soap-bV-rope-flash-seed42 |
| 2 | **3.347** | ECD | bQ+bV | ecd-bQ+bV-stdV0.02-seed42 |
| 3 | 3.358 | ECD | bQ+bV+RoPE | ecd-bV-rope-flash-seed1122 |
| 4 | 3.374 | SOAP | bQ+bV | soap-bV-flash-seed123 |
| 5 | 3.416 | SOAP | symmetric | 124m-ctx512-symmetric-soap |
| 6 | 3.531 | AdamW | bQ+bV | adamw-bV-stdV0.05-seed42 |
| 7 | 3.572 | AdamW | symmetric | adamw-124m-extended-symmetric-lr0.0001-seed42 |
| 8 | 3.666 | SGDM | bQ+bV | sgdm-bV-stdV0.05-seed123 |

### Best Runs by Optimizer and Config (500M tokens)

| Optimizer | Config | Val Loss | Run Name |
|-----------|--------|----------|----------|
| **ECD** | symmetric | 3.933 | ecd-124m-symmetric-lrhat1.0-seed42 |
| **ECD** | bQ-only | 3.847 | ecd-124m-extended-eta100-F02-lrhat1.0-seed123 |
| **ECD** | bQ+bV | **3.347** | ecd-bQ+bV-stdV0.02-seed42 |
| **ECD** | bQ+bV+RoPE | 3.358 | ecd-bV-rope-flash-seed1122 |
| **SGDM** | symmetric | 3.842 | sgdm-124m-extended-symmetric-lr0.0300-seed123 |
| **SGDM** | bQ-only | 3.800 | sgdm-124m-extended-disordered-lr0.0300-seed123 |
| **SGDM** | bQ+bV | **3.666** | sgdm-bV-stdV0.05-seed123 |
| **AdamW** | symmetric | 3.572 | adamw-124m-extended-symmetric-lr0.0001-seed42 |
| **AdamW** | bQ-only | 3.574 | adamw-124m-extended-best-lr0.0001-seed42 |
| **AdamW** | bQ+bV | **3.531** | adamw-bV-stdV0.05-seed42 |
| **SOAP** | symmetric | 3.416 | 124m-ctx512-symmetric-soap |
| **SOAP** | bQ-only | 4.163 | soap-124m-extended-disordered-lr0.0010-seed42 |
| **SOAP** | bQ+bV | 3.374 | soap-bV-flash-seed123 |
| **SOAP** | bQ+bV+RoPE | **3.331** | soap-bV-rope-flash-seed42 |

## Key Findings

### 1. SOAP bQ+bV+RoPE Achieves Best Val Loss at 500M Tokens

At 500M tokens with fair comparison:
- **SOAP bQ+bV+RoPE**: 3.331 (soap-bV-rope-flash-seed42) - **Best overall**
- **ECD bQ+bV**: 3.347 (ecd-bQ+bV-stdV0.02-seed42) - **Best without RoPE**

### 2. All Optimizers Benefit from bQ+bV

Every optimizer achieves its best (or near-best) results with symmetry breaking:

| Optimizer | Best Config | Improvement over Symmetric |
|-----------|-------------|---------------------------|
| **ECD** | bQ+bV | 3.933 → 3.347 (-0.59) |
| **SGDM** | bQ+bV | 3.842 → 3.666 (-0.18) |
| **AdamW** | bQ+bV | 3.572 → 3.531 (-0.04) |
| **SOAP** | bQ+bV+RoPE | 3.416 → 3.331 (-0.09) |

### 3. ECD Shows Largest Benefit from Symmetry Breaking

ECD improves by **0.59** from symmetric to bQ+bV, the largest improvement of any optimizer. This aligns with the theoretical prediction that ECD dynamics benefit most from breaking rotational symmetries.

### 4. AdamW is Relatively Insensitive to Configuration

AdamW shows minimal variation across configs (~3.53-3.57), suggesting its adaptive learning rates implicitly handle symmetries.

### 5. SOAP bQ-only Performs Poorly

SOAP with bQ-only (4.163) significantly underperforms all other SOAP configurations, suggesting SOAP needs either full symmetry (symmetric) or full symmetry breaking (bQ+bV).

### 6. Val Loss vs Logic Puzzle Performance

**Critical finding**: Lower validation loss does NOT correlate with better reasoning performance!
- Models with symmetric config score 0% on logic puzzles (regardless of val loss)
- Models with bQ-only achieve up to 100% on some reasoning tasks
- ECD with bQ+bV achieves both good val loss (3.35) AND retains reasoning ability

See `logic_puzzles/README.md` for detailed analysis.

## Smoothed Validation Loss Analysis

We apply exponential weighted moving average (EWM) smoothing with alpha=0.1 to validation loss curves to get robust estimates that are less sensitive to noise.

### Smoothed Results (500M tokens) - All 14 Best Runs

**Metrics**:
- `raw_min`: Best validation loss during training (what you'd checkpoint)
- `sm_min`: Best value of the smoothed curve (less noisy estimate of best)
- `sm_final`: Final value of smoothed curve (where training converged)

| Rank | raw_min | sm_min | sm_final | Optimizer | Config | Run Name |
|------|---------|--------|----------|-----------|--------|----------|
| 1 | 3.331 | 4.142 | 4.161 | SOAP | bQ+bV+RoPE | soap-bV-rope-flash-seed42 |
| 2 | 3.347 | 4.032 | 4.032 | ECD | bQ+bV | ecd-bQ+bV-stdV0.02-seed42 |
| 3 | 3.358 | 4.055 | 4.055 | ECD | bQ+bV+RoPE | ecd-bV-rope-flash-seed1122 |
| 4 | 3.374 | 4.186 | 4.207 | SOAP | bQ+bV | soap-bV-flash-seed123 |
| 5 | 3.416 | 4.178 | 4.202 | SOAP | symmetric | 124m-ctx512-symmetric-soap |
| 6 | 3.531 | 4.307 | 4.327 | AdamW | bQ+bV | adamw-bV-stdV0.05-seed42 |
| 7 | 3.572 | 3.695 | 3.696 | AdamW | symmetric | adamw-124m-extended-symmetric |
| 8 | 3.574 | 3.696 | 3.698 | AdamW | bQ-only | adamw-124m-extended-best |
| 9 | 3.666 | 4.247 | 4.247 | SGDM | bQ+bV | sgdm-bV-stdV0.05-seed123 |
| 10 | 3.800 | 3.884 | 3.898 | SGDM | bQ-only | sgdm-124m-extended-disordered |
| 11 | 3.842 | 3.926 | 3.940 | SGDM | symmetric | sgdm-124m-extended-symmetric |
| 12 | 3.847 | 3.984 | 3.984 | ECD | bQ-only | ecd-124m-extended-eta100-F02 |
| 13 | 3.933 | 4.011 | 4.024 | ECD | symmetric | ecd-124m-symmetric-lrhat1.0 |
| 14 | 4.163 | 4.268 | 4.270 | SOAP | bQ-only | soap-124m-extended-disordered |

**Note**: For most runs, `sm_min ≈ sm_final`, meaning the smoothed curve reaches its best near the end of training.

### Key Smoothing Observations

1. **Raw Min vs Smoothed Min Gap** (all runs are 500M tokens):
   - Runs with "-bV-" in name show large gap (~0.7): steeper training curves
   - Other runs show smaller gap (~0.1-0.2): more gradual convergence
   - The gap reflects training curve shape, not token count (all are 500M)

2. **Smoothed Final (End of Training)** - Best by Optimizer:
   | Optimizer | Best sm_final | Config | Run |
   |-----------|---------------|--------|-----|
   | **AdamW** | **3.696** | symmetric | adamw-124m-extended-symmetric |
   | **SGDM** | **3.898** | bQ-only | sgdm-124m-extended-disordered |
   | **ECD** | **3.984** | bQ-only | ecd-124m-extended-eta100-F02 |
   | **SOAP** | **4.161** | bQ+bV+RoPE | soap-bV-rope-flash-seed42 |

3. **Why "-bV-" Runs Have Higher Smoothed Values**:
   - "-bV-" runs hit their **minimum mid-training**, then loss **increases again**
   - Other runs converge more stably, with final loss close to minimum
   - This explains the gap: bV raw_min ~3.3, bV final ~4.3 (gap ~1.0)
   - Both metrics are valid: raw_min = best checkpoint, smoothed_final = end-of-training state

4. **Ranking Changes with Smoothing**:
   - By **raw_min**: SOAP bQ+bV+RoPE (3.33) > ECD bQ+bV (3.35) > SOAP bQ+bV (3.37)
   - By **smoothed_final**: AdamW symmetric (3.70) > SGDM bQ-only (3.90) > SGDM symmetric (3.94)
   - The choice of metric depends on whether you care about best checkpoint or end-of-training performance

### Smoothing Methodology

- **Algorithm**: Exponential Weighted Moving Average (EWM)
- **Alpha**: 0.1 (lower = smoother)
- **Formula**: `smoothed[t] = alpha * raw[t] + (1-alpha) * smoothed[t-1]`
- **Data Points**: ~122-246 validation checkpoints per run

### Stored Curve Data

The actual validation loss curves are stored in `results/curves/`:
- `all_curves.csv`: All 13 curves in one file (columns = run names)
- `[run_name].csv`: Individual curve files with step and val_loss columns

Additional smoothing analyses:
- `late_smoothing_comparison.csv`: Smoothing starting at 0%, 10%, 20%, 50% of training
- `last_portion_smoothing.csv`: Smoothing only last 5%, 10%, 20% of training

## Configuration Definitions

| Config | Description |
|--------|-------------|
| **symmetric** | Standard transformer, no symmetry breaking |
| **bQ-only** | Random query bias bQ added (breaks Q-K rotation symmetry) |
| **bQ+bV** | Random query bias bQ + value bias bV |
| **bQ+bV+RoPE** | bQ+bV with Rotary Position Embeddings |

## Running the Analysis

### Analyze WandB Exports

```bash
python scripts/analyze_wandb_exports.py
```

This processes the `wandb_export_*.csv` files and generates:
- `results/best_runs_500M_tokens.csv`: Best run for each optimizer/config at 500M tokens

### Fetch Latest WandB Data via API

```bash
# Analyze all finished runs in ecd-full-symbreak project
python scripts/wandb_smoothed_analysis.py

# Analyze specific project
python scripts/wandb_smoothed_analysis.py --project ecd-scale --output results/ecd_scale_latest.csv
```

## WandB Projects Analyzed

| Project | Description | N Runs |
|---------|-------------|--------|
| `ecd-full-symbreak` | Main bQ+bV experiments | 20 |
| `ecd-scale` | Scaling experiments | 16 |
| `ecd-vs-soap-extended-500M` | Extended 500M token runs | 21 |
| `ecd-vs-soap-hp-scan` | Hyperparameter scans | 200+ |

## Data Sources

1. **WandB Exports**: Primary source - CSV exports from WandB UI
2. **WandB API**: For fetching additional run details and history

## Reproducibility Notes

- All WandB runs are from entity `ecdsep-arxiv`
- Comparisons filtered to 400M-600M tokens for fair comparison
- Local checkpoints are `model_best.pt` files in `experiments/ecd_vs_soap/results/124m_extended/`
